#include <iostream>
#include <cassert>

#include "hash_list.h"

// A unit test for a basic constructor
void t_constructor(void){
  hash_list list;

  if(list.get_size() != 0){
    std::cout << "t_constructor: invalid size" << std::endl;
  }
}

/*******
 Unit test to check if insertion into an empty list
 works. More unit tests would be recommended for
 testing insert. Could you think of what other tests one
 might consider?
**********/

void t_insert_empty(void){
  hash_list list;

  list.insert(1, 7.0);
  
  if(list.get_size() != 1){
    std::cout << "t_insert_empty: invalid size" << std::endl;
    return;
  }

  if(!list.get_value(1).has_value()){
    std::cout << "Expected value but says no value" << std::endl;
    return;
  }

  if(!(list.get_value(1).value() == 7.0)){
    std::cout << "Value does not match" << std::endl;
  }
}


int main(int argc, char *argv[])
{
  t_constructor();
  t_insert_empty();
}
